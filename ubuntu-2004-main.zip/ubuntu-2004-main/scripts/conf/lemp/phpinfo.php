<?php
	/**
	* Autor: Robson Vaamonde
	* Site: www.procedimentosemti.com.br
	* Facebook: facebook.com/ProcedimentosEmTI
	* Facebook: facebook.com/BoraParaPratica
	* YouTube: youtube.com/BoraParaPratica
	* Linkedin: https://www.linkedin.com/in/robson-vaamonde-0b029028/
	* Instagram: https://www.instagram.com/procedimentoem/?hl=pt-br
	* Data de criação: 15/10/2021
	* Data de atualização: 15/10/2021
	* Versão: 0.01
	* Testado e homologado para a versão do Ubuntu Server 20.04.x LTS x64x
	* Testado e homologado para a versão do Nginx v.x
	* Testado e homologado para a versão do PHP v7.4
	*/

	/** Módulo do PHP para gerar a página de documentação e parâmetros do PHP*/
	phpinfo(); 
?>